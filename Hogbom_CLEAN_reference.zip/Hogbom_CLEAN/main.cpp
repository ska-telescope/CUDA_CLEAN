#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <Eigen/Dense>

using namespace Eigen;
using namespace std;

typedef unsigned int uint;

// define the format you want, you only need one instance of this...
const static IOFormat CSVFormat(StreamPrecision, DontAlignCols, ", ", "\n");

template<typename M>
void writeMatrixToCSVfile(string name, M matrix)
{
	ofstream file(name.c_str());
	file << matrix.format(CSVFormat);
}

template<typename M>
M readMatrixFromCSVfile(const std::string & path) 
{
	std::ifstream indata;
	indata.open(path);
	std::string line;
	std::vector<double> values;
	uint rows = 0;
	while (std::getline(indata, line)) 
	{
		std::stringstream lineStream(line);
		std::string cell;
		while (std::getline(lineStream, cell, ',')) 
		{
			values.push_back(std::stod(cell));
		}
		++rows;
	}
	return Map<const Matrix<typename M::Scalar, M::RowsAtCompileTime, M::ColsAtCompileTime, RowMajor>>(values.data(), rows, values.size() / rows);
}

//void readMatrixToCSVfile(string name, MatrixXd matrix)
//{
//	ofstream file(name.c_str());
//	file << matrix.format(CSVFormat);
//}

void CheckTopLeftAndSize(Array2i &topleftOverlap, Array2i &sizeOverlap, Array2i maxSize)
{
	for (uint iDim = 0; iDim < 2; iDim++)
	{
		if (topleftOverlap(iDim) < 0)
			topleftOverlap(iDim) = 0;
	}

	for (uint iDim = 0; iDim < 2; iDim++)
	{
		if ((topleftOverlap(iDim) + sizeOverlap(iDim)) >= maxSize(iDim))
			sizeOverlap(iDim) = maxSize(iDim) - topleftOverlap(iDim) - 1;
	}
}

void CheckCorners(Array2i &tlc, Array2i &brc, Array2i maxSize)
{
	// check tlc
	for (uint iDim = 0; iDim < 2; iDim++)
	{
		if (tlc(iDim) < 0 || tlc(iDim) > maxSize(iDim) - 1)
			tlc(iDim) = 0;
	}

	// check brc
	for (uint iDim = 0; iDim < 2; iDim++)
	{
		if (brc(iDim) < 0 || brc(iDim) > maxSize(iDim) - 1)
			brc(iDim) = maxSize(iDim) - 1;
	}
}

void CheckOverlapsSameSize(Array2i &tlOverlap1, Array2i &sizeOverlap1, Array2i &tlOverlap2, Array2i &sizeOverlap2)
{
	if ((sizeOverlap1 - sizeOverlap2).prod() == 0)
		return;

	// this needs to be improved and test for edge cases
}

int main()
{
	double loopGain = 0.1;
	uint numMinorCycles = 60;

	// read in PSF and Dirty Image
	cout << "Reading PSF ... ";
	MatrixXd PSF = readMatrixFromCSVfile<MatrixXd>("../data/PSF_20rx.dat");
	cout << "done!" << endl;
	cout << "PSF is " << PSF.rows() << " by " << PSF.cols() << endl;

	cout << "Reading DI ... ";
	MatrixXd DI = readMatrixFromCSVfile<MatrixXd>("../data/DI_20rx_7s_infdB.dat");
	cout << "done!" << endl;
	cout << "DI is " << DI.rows() << " by " << DI.cols() << endl;

	uint N = (uint)PSF.rows();  // NB: we assume N is even and that PSF and DI are square, and the same size!

	MatrixXd MI(N, N);// Model Image
	MI.setZero();

	MatrixXi::Index maxRow, maxCol;
	double peakVal;

	Array2i posPSFPeak(1, 2);

	peakVal = PSF.cwiseAbs().maxCoeff(&maxRow, &maxCol);

	posPSFPeak << (uint)maxRow, (uint)maxCol;

	cout << "peak of PSF is " << PSF(posPSFPeak(0), posPSFPeak(1)) << " at (" << posPSFPeak(0) << ", " << posPSFPeak(1) << ")" << endl;
	cout << "Normalising PSF and DI ... " << endl;
	PSF /= peakVal;
	DI  /= peakVal;
	peakVal = PSF.cwiseAbs().maxCoeff(&maxRow, &maxCol);
	cout << "peak of PSF is " << PSF(maxRow, maxCol) << " at (" << maxRow << ", " << maxCol << ")" << endl;

	//cout << "PSF centre =" << endl << PSF.block(maxRow - 2, maxCol - 2, 5, 5) << endl;

	//PSF.block(maxRow - 1, maxCol - 1, 3, 3) *= 2;
	//cout << "PSF centre =" << endl << PSF.block(maxRow - 2, maxCol - 2, 5, 5) << endl;

	for (uint iMinorCycle = 0; iMinorCycle < numMinorCycles; iMinorCycle++)
	{
		peakVal = DI.cwiseAbs().maxCoeff(&maxRow, &maxCol);
		//cout << "peak of DI is " << DI(maxRow, maxCol) << " at (" << maxRow << ", " << maxCol << ")" << endl;

		Array2i posDIPeak(1, 2);

		posDIPeak << (uint)maxRow, (uint)maxCol;

		Array2i tlcDIOverlap(1, 2);  // top left corner 
		Array2i brcDIOverlap(1, 2); // top left corner 
		Array2i tlcPSFOverlap(1, 2); // bottom right corner
		Array2i brcPSFOverlap(1, 2); // bottom right corner
		Array2i sizeDIOverlap(1, 2);
		Array2i sizePSFOverlap(1, 2);
		Array2i sizeImage(1, 2);

		sizePSFOverlap << N, N;
		sizeDIOverlap << N, N;
		sizeImage << N, N;

		tlcDIOverlap = posDIPeak - N / 2;
		brcDIOverlap = posDIPeak + N / 2 - 1;

		//cout << "DI overlap corners" << " at (" << tlcDIOverlap(0) << ", " << tlcDIOverlap(1) << ") and (" << brcDIOverlap(0) << ", " << brcDIOverlap(1) << ")" << endl;
		CheckCorners(tlcDIOverlap, brcDIOverlap, sizeImage);
		//cout << "DI overlap corners" << " at (" << tlcDIOverlap(0) << ", " << tlcDIOverlap(1) << ") and (" << brcDIOverlap(0) << ", " << brcDIOverlap(1) << ")" << endl;

		tlcPSFOverlap = tlcDIOverlap + posPSFPeak - posDIPeak;
		brcPSFOverlap = brcDIOverlap + posPSFPeak - posDIPeak;

		//cout << "PSF overlap corners" << " at (" << tlcPSFOverlap(0) << ", " << tlcPSFOverlap(1) << ") and (" << brcPSFOverlap(0) << ", " << brcPSFOverlap(1) << ")" << endl;
		CheckCorners(tlcPSFOverlap, brcPSFOverlap, sizeImage);
		//cout << "PSF overlap corners" << " at (" << tlcPSFOverlap(0) << ", " << tlcPSFOverlap(1) << ") and (" << brcPSFOverlap(0) << ", " << brcPSFOverlap(1) << ")" << endl;

		CheckOverlapsSameSize(tlcDIOverlap, sizeDIOverlap, tlcPSFOverlap, sizePSFOverlap);

		//cout << "DI overlap corners" << " at (" << tlcDIOverlap(0) << ", " << tlcDIOverlap(1) << ") and (" << brcDIOverlap(0) << ", " << brcDIOverlap(1) << ")" << endl;
		//cout << "PSF overlap corners" << " at (" << tlcPSFOverlap(0) << ", " << tlcPSFOverlap(1) << ") and (" << brcPSFOverlap(0) << ", " << brcPSFOverlap(1) << ")" << endl;

		// update model image
		//cout << "MI at (" << posDIPeak(0) << ", " << posDIPeak(1) << ") is " << MI(posDIPeak(0), posDIPeak(1)) << endl;
		MI(posDIPeak(0), posDIPeak(1)) += DI(posDIPeak(0), posDIPeak(1))*loopGain;
		//cout << "MI at (" << posDIPeak(0) << ", " << posDIPeak(1) << ") is " << MI(posDIPeak(0), posDIPeak(1)) << endl;

		// update dirty image
		//cout << "DI at (" << posDIPeak(0) << ", " << posDIPeak(1) << ") is " << DI(posDIPeak(0), posDIPeak(1)) << endl;
		DI.block(tlcDIOverlap(0), tlcDIOverlap(1), brcDIOverlap(0) - tlcDIOverlap(0) + 1, brcDIOverlap(1) - tlcDIOverlap(1) + 1)
			-= loopGain * DI(posDIPeak(0), posDIPeak(1)) * PSF.block(tlcPSFOverlap(0), tlcPSFOverlap(1), brcPSFOverlap(0) - tlcPSFOverlap(0) + 1, brcPSFOverlap(1) - tlcPSFOverlap(1) + 1);
		//cout << "DI at (" << posDIPeak(0) << ", " << posDIPeak(1) << ") is " << DI(posDIPeak(0), posDIPeak(1)) << endl;
		
		double totalFlux = MI.sum();

		cout << setw(3) << iMinorCycle << "   " << setw(12) << peakVal << " at [" << setw(4) << posDIPeak(0) << ", " << setw(4) << posDIPeak(1) << "]" << "     " << totalFlux <<endl;

	} // for (uint iMinorCycle = 0; iMinorCycle < numMinorCycles; iMinorCycle++)

	// write output
	cout << "Writing Model and Residual Images..." << endl;
	writeMatrixToCSVfile(   "../data/linux_test_ModelImage40.dat", MI);
	writeMatrixToCSVfile("../data/linux_test_ResidualImage40.dat", DI);

	// finished!
	cout << endl << "Press ENTER to exit...";
	cin.get();
}
