cd build
cmake ..
make
./hogbom
